import Foundation

final class EchoPlugin: OmegaPlugin {

    let name = "echo"

    func execute(_ arg: String, context: AppContext) -> String {
        return arg
    }
}
