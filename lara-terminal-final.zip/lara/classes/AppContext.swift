import Foundation

final class AppContext {

    static let shared = AppContext()
    let mgr = laramgr.shared

    private init() {
        HotPluginManager.shared.register(StatusPlugin())
    }

    func getStatus() -> String {
        return """
OMEGA STATUS
dsrunning: \(mgr.dsrunning)
dsready: \(mgr.dsready)
dsattempted: \(mgr.dsattempted)
vfsready: \(mgr.vfsready)
sbxrunning: \(mgr.sbxrunning)
"""
    }

    func getLogs() -> String {
        mgr.log
    }

    func runSystem() -> String {
        mgr.run()
        return "run ok"
    }

    func triggerRespring() -> String {
        mgr.showrespring = true
        return "respring ok"
    }
}
