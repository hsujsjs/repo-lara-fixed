import Foundation

final class OmegaCore {

    typealias Handler = (String, laramgr) -> CommandResult

    static var commands: [String: Handler] = [:]

    static var pipeBuffer: String? = nil

    static func register(_ name: String, _ handler: @escaping Handler) {
        commands[name] = handler
    }

    static func execute(_ input: String, context mgr: laramgr) -> CommandResult {
        let cmd = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cmd.isEmpty else { return .fail("empty command") }

        let parts = cmd.split(separator: " ", maxSplits: 1).map { String($0) }
        let key   = parts[0].lowercased()
        let arg   = parts.count > 1 ? parts[1] : ""

        guard let handler = commands[key] else {
            return .fail("\(key): command not found — type 'help' for list")
        }
        return handler(arg, mgr)
    }

    static func executePiped(_ input: String, stdin: String, context mgr: laramgr) -> CommandResult {
        pipeBuffer = stdin
        let result = execute(input, context: mgr)
        pipeBuffer = nil
        return result
    }
}
