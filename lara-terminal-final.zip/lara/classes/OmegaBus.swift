import Foundation

final class OmegaBus {

    static let shared = OmegaBus()

    private init() {}

    typealias Handler = (String, Any?) -> Void

    private var listeners: [String: [Handler]] = [:]

    func on(_ event: String, _ handler: @escaping Handler) {
        listeners[event, default: []].append(handler)
    }

    func emit(_ event: String, _ data: Any? = nil) {
        listeners[event]?.forEach { $0(event, data) }
    }
}
