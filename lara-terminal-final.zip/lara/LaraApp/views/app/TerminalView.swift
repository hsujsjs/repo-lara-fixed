import SwiftUI

private struct TerminalLine: Identifiable {
    let id = UUID()
    let text: String
    let kind: Kind
    enum Kind { case input, output, error, system }
}

struct TerminalView: View {

    @State private var input: String = ""
    @State private var lines: [TerminalLine] = []
    @State private var cmdHistory: [String] = []
    @State private var histIdx: Int = -1
    @State private var prompt: String = "/"
    @FocusState private var focused: Bool

    var body: some View {
        VStack(spacing: 0) {
            outputArea
            Divider().background(Color.green.opacity(0.4))
            inputBar
        }
        .background(Color.black)
        .navigationTitle("Terminal")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar { toolbarContent }
        .onAppear {
            OmegaBootstrap.start()
            cmdHistory = TerminalHistory.shared.load()
            prompt = OmegaFS.shared.cwd
            append("LARA Shell — type 'help' for commands", .system)
            append("cwd: \(prompt)", .system)
            focused = true
        }
    }

    private var outputArea: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 1) {
                    ForEach(lines) { line in
                        Text(line.text)
                            .font(.system(size: 12.5, design: .monospaced))
                            .foregroundColor(lineColor(line.kind))
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .textSelection(.enabled)
                            .id(line.id)
                    }
                }
                .padding(8)
            }
            .background(Color.black)
            .onChange(of: lines.count) { _ in
                withAnimation(.easeOut(duration: 0.15)) {
                    proxy.scrollTo(lines.last?.id, anchor: .bottom)
                }
            }
        }
    }

    private var inputBar: some View {
        HStack(spacing: 6) {
            Text("\(shortenedPrompt)]$")
                .font(.system(size: 11, design: .monospaced))
                .foregroundColor(.green)
                .lineLimit(1)
                .minimumScaleFactor(0.6)

            TextField("", text: $input)
                .font(.system(size: 13, design: .monospaced))
                .foregroundColor(.green)
                .tint(.green)
                .autocorrectionDisabled()
                .textInputAutocapitalization(.never)
                .focused($focused)
                .onSubmit { run() }
                .submitLabel(.done)

            Button { histUp() } label: {
                Image(systemName: "chevron.up")
                    .foregroundColor(.green)
                    .frame(width: 28, height: 28)
            }
            .buttonStyle(.plain)

            Button { histDown() } label: {
                Image(systemName: "chevron.down")
                    .foregroundColor(.green)
                    .frame(width: 28, height: 28)
            }
            .buttonStyle(.plain)

            Button("↵") { run() }
                .font(.system(size: 13, weight: .semibold, design: .monospaced))
                .foregroundColor(.black)
                .padding(.horizontal, 10)
                .padding(.vertical, 5)
                .background(Color.green)
                .cornerRadius(5)
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 6)
        .background(Color.black)
    }

    @ToolbarContentBuilder
    private var toolbarContent: some ToolbarContent {
        ToolbarItem(placement: .navigationBarLeading) {
            Button("Copy") {
                UIPasteboard.general.string = lines.map { $0.text }.joined(separator: "\n")
                UIImpactFeedbackGenerator(style: .light).impactOccurred()
            }
            .foregroundColor(.green)
        }
        ToolbarItem(placement: .navigationBarTrailing) {
            Button("Clear") {
                lines.removeAll()
                append("LARA Shell — cleared", .system)
            }
            .foregroundColor(.green)
        }
    }

    private var shortenedPrompt: String {
        if prompt == "/" { return "/" }
        if let last = prompt.split(separator: "/").last { return String(last) }
        return prompt
    }

    private func lineColor(_ kind: TerminalLine.Kind) -> Color {
        switch kind {
        case .input:  return .yellow
        case .output: return .green
        case .error:  return .red
        case .system: return Color(white: 0.55)
        }
    }

    private func append(_ text: String, _ kind: TerminalLine.Kind) {
        lines.append(TerminalLine(text: text, kind: kind))
    }

    private func run() {
        let raw = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !raw.isEmpty else { return }

        input = ""
        histIdx = -1
        if cmdHistory.first != raw {
            cmdHistory.insert(raw, at: 0)
            TerminalHistory.shared.save(raw)
        }

        append("lara:\(shortenedPrompt)]$ \(raw)", .input)

        let mgr = laramgr.shared
        let result = OmegaCore.execute(raw, context: mgr)

        if result.output == "__CLEAR__" {
            lines.removeAll()
            append("LARA Shell — cleared", .system)
        } else if !result.output.isEmpty {
            for line in result.output.split(separator: "\n", omittingEmptySubsequences: false) {
                append(String(line), result.isError ? .error : .output)
            }
        }

        prompt = OmegaFS.shared.cwd
        focused = true
    }

    private func histUp() {
        guard !cmdHistory.isEmpty else { return }
        histIdx = min(histIdx + 1, cmdHistory.count - 1)
        input = cmdHistory[histIdx]
    }

    private func histDown() {
        if histIdx <= 0 { histIdx = -1; input = "" }
        else { histIdx -= 1; input = cmdHistory[histIdx] }
    }
}
